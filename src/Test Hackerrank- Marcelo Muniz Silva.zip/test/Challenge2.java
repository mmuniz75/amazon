package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class Challenge2 {

	@Test
	public void test() {
		assertEquals(2,minimumNumberOfTrips(100, new int[]{70,10,20}));
	}
	
	@Test
	public void test3() {
		assertEquals(4,minimumNumberOfTrips(100, new int[]{70,10,20,90,100}));
	}
	
	@Test
	public void test4() {
		assertEquals(4,minimumNumberOfTrips(100, new int[]{70,10,20,90,100}));
	}
	
	@Test
	public void test5() {
		assertEquals(0,minimumNumberOfTrips(100, new int[]{}));
	}

	
	 static int minimumNumberOfTrips(int tripMaxWeight, int[] packagesWeight) {
		 
		 if(packagesWeight.length==0) return 0;
		 
         int countTrip = 1;
         int countPackages = 0;
         for(int i=0;i<packagesWeight.length;i++){
        	 countPackages++;
        	 if(countPackages>2){
        		 tripMaxWeight = 0;
        		 countPackages = 0;
        	 }
        	 
        	 tripMaxWeight -= packagesWeight[i];
             if(tripMaxWeight<0){
                 countTrip++;
                 tripMaxWeight=100-packagesWeight[i];    
             }
         }

      return countTrip;
  }
}
